/**
 * 1. Initialize an XMLHttpRequest constructor
 * 2. Open a GET request, set the headers and response type
 * 3. Output successful response
 * 4. Output error state
 * 5. Combine with an event listener (button)
 * 6. Adjust UI states accordingly
 * 7. Bonus: change button CTA to indicate if it's the first joke or a "next" one
 */

const API_ENDPOINT = 'https://icanhazdadjoke.com/';
const XHR = new XMLHttpRequest();

function showJoke(joke){
    setLoaderState(false);
    document.getElementById('joke').innerHTML=joke;
}

function showError(error){
    setLoaderState(false);
    document.getElementById('error-message').innerHTML=error
    document.getElementById('error-message').style.display='block';
}
function setLoaderState(isVisible){
    const displayState=isVisible ? 'block' : 'none';
   document.getElementById('loader').style.display=displayState;

}

function  setButtonCta(isError){
    const buttonCta=isError ? 'Try again' : 'Get another one';
    buttonCtaSelector.innerHTML=buttonCta;
}
function getJoke(){
    XHR.open('GET', API_ENDPOINT);
    XHR.setRequestHeader('Accept', 'application/json'); 
    XHR.responseType= 'json';

    XHR.onload=function(){
        console.log('Success', XHR.response.joke);
        showJoke(XHR.response.joke)
        setButtonCta(false)
}
    XHR.onerror = function(){
        showError('An error occurred, please try again.');
        setButtonCta(true)
    }
 XHR.send();
}
document.getElementById('button').addEventListener('click', function(){
    setLoaderState(true);
    getJoke();
});